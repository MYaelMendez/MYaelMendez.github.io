# NOTICES

## This kit

`SKILL.md`, `scripts/`, and `generators/` are MIT licensed — the same terms as
the Hermes Agent project they extend. Attribution is appreciated, not required.

## The rendered atlas is a different matter

A sprite atlas is a **derivative work of the asset you rendered**. It inherits
that asset's licence — not the licence of the renderer.

For the Asimov-1 humanoid:

| asset | licence | source |
|---|---|---|
| Asimov-1 **hardware** CAD (the STL meshes) | **CERN-OHL-S-2.0** (strongly reciprocal) | Menlo Research — `menloresearch/asimov-1` |
| Asimov-1 **sim model / locomotion policy** | **Apache-2.0** | Menlo Research — `Menlo/asimov1-locomotion-0818` |
| MuJoCo | Apache-2.0 | DeepMind |

Consequences, stated plainly and not as legal advice:

- An atlas rendered from the hardware CAD is a derivative of a
  **CERN-OHL-S-2.0** work. CERN-OHL-S is a strongly reciprocal (copyleft)
  licence: a derivative that is **conveyed** must be distributed under the same
  licence, with the source of the derivative available.
- "Conveyed" is the trigger. A pet you render and keep for yourself is not
  conveyed. Publishing it — to a gallery, a repo, a teammate — is.
- The **generator** (this kit) is a separate work and stays MIT. What it
  *produces* from reciprocal input is not.
- Reproduce the upstream licence text verbatim beside any atlas you publish,
  and point at the source rather than redistributing the raw CAD.

If you render a different subject, look up that subject's licence and apply the
same reasoning. When in doubt, ask — and do not ship.

## Third-party code in the generators

`generators/` contains no vendored third-party code. It imports `numpy`,
`Pillow`, and (for the browser scene) a vendored copy of `three.js`, which is
MIT licensed and carries its own licence text in its header.
