---
name: petdex
description: Install and select animated petdex mascots for Hermes.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [petdex, mascot, display, cli, tui, desktop]
    category: productivity
    homepage: https://petdex.dev
---

# Petdex Skill

Browse, install, and select animated "pet" mascots from the public
[petdex](https://github.com/crafter-station/petdex) gallery. An installed pet
reacts to agent activity (idle, running a tool, reviewing, error, done) across
the Hermes CLI, TUI, and desktop app. This skill drives the `hermes pets` CLI
and the `display.pet` config, and covers authoring a custom pet locally.

## When to Use

- The user wants a desktop/terminal mascot or asks about "pets" / petdex.
- The user wants to change, preview, or disable the active pet.
- Diagnosing why a pet isn't showing (terminal graphics support, config).

## Prerequisites

- Network access to `petdex.dev` for the gallery/manifest (read-only, no auth).
- Pillow (a core Hermes dependency) for sprite decoding — already installed.
- For full-fidelity terminal rendering: a graphics-capable terminal (kitty,
  Ghostty, WezTerm, iTerm2, or sixel). Otherwise a truecolor Unicode
  half-block fallback is used automatically.

## How to Run

Use the `terminal` tool to run `hermes pets <subcommand>`.

## Quick Reference

| Goal | Command |
| --- | --- |
| Browse the gallery | `hermes pets list` (add a substring to filter: `hermes pets list cat`) |
| List installed pets | `hermes pets list --installed` |
| Install a pet | `hermes pets install <slug>` (add `--select` to make it active) |
| Set the active pet | `hermes pets select <slug>` (omit slug for a picker) |
| Resize the pet everywhere | `hermes pets scale <factor>` (e.g. `0.5`, clamped 0.1–3.0) |
| Preview/animate in terminal | `hermes pets show [slug] [--cycle] [--state run]` |
| Disable the pet | `hermes pets off` |
| Remove a pet | `hermes pets remove <slug>` |
| Diagnose setup | `hermes pets doctor` |

## Procedure

1. Find a pet: `hermes pets list <query>` and note its `slug`.
2. Install + activate: `hermes pets install <slug> --select`.
3. Preview it: `hermes pets show` (Ctrl+C to stop).
4. Confirm setup: `hermes pets doctor` — shows the resolved pet, configured
   render mode, detected terminal graphics protocol, and effective mode.

Pets install into `<HERMES_HOME>/pets/<slug>/` (profile-aware). Selecting a pet
writes `display.pet.slug` + `display.pet.enabled` to `config.yaml`.

## Configuration

Under `display.pet` in `config.yaml`:

- `enabled` (bool) — master on/off.
- `slug` (str) — active pet; empty = first installed.
- `render_mode` — `auto` (detect) | `kitty` | `iterm` | `sixel` | `unicode` | `off`.
- `scale` (float) — on-screen size of the native 192×208 frames (default 0.33,
  clamped 0.1–3.0). One knob resizes every surface; set it with
  `hermes pets scale <factor>`, the `/pet scale` slash command, or the desktop
  Appearance slider.
- `unicode_cols` (int) — width in columns for the Unicode fallback.

## Authoring a custom pet

A pet is two files in `<HERMES_HOME>/pets/<slug>/`; no gallery entry, no upload,
no account. Write them, then `hermes pets select <slug>`.

```
pet.json          {id, displayName, description, spritesheetPath, createdBy}
spritesheet.webp  1536x1872 RGBA = 8 cols x 9 rows of 192x208
```

**Read the row taxonomy from the installed source, never from the state names
in prose.** `agent/pet/constants.py` is authoritative: `FRAME_W/FRAME_H`,
`FRAMES_PER_STATE = 6` (columns 6–7 are ignored), and `CODEX_STATE_ROWS` in
order — `idle, running-right, running-left, waving, jumping, failed, waiting,
running, review`. Legacy 8-row sheets use a different order and the renderer
infers which from the sheet height, so a wrong row count silently maps every
state to the wrong animation.

**A pet needs ALPHA; a film renderer does not produce it.** A renderer that
paints a background gradient behind the subject yields an opaque tile that
shows as a rectangle on the desktop. Fork only the shade pass: where no
triangle won the depth test write `rgba(0,0,0,0)`, otherwise write the colour
with `alpha=255`. Keep the depth kernel and lighting identical so the pet and
any films are the same object under the same light.

**Give every row a time term, then verify uniqueness by HASH.** A pose computed
without the frame index is one image repeated six times — a state that does not
animate. Run [scripts/validate_atlas.py](scripts/validate_atlas.py) on the finished
slug: it checks the atlas geometry, the alpha mode, per-row frame uniqueness, the
opaque-pixel floor and `pet.json`. **Do not judge animation by looking**: subtle
motion at 192 px reads as static to the eye (and to a vision model) while every
frame is genuinely different.

**Abort on a near-empty frame.** Count opaque pixels per frame and refuse below
a floor (~500 at 192×208). An off-camera or degenerate pose otherwise ships as a
blank pet that installs and selects cleanly.

**Pose from the model's real joint names.** Grep the link/joint list for the
limb you want (`shoulder` + `pitch|roll`) rather than inventing an identifier;
a wrong name is silently ignored and the wave never happens.

**Give each locomotion row its OWN motion source.** Replaying one walk trace at
three yaws makes `running`, `running-right` and `running-left` the same gait in
three costumes — the rows differ only by the body's yaw offset. Drive them from
distinct commands (a `vx` walk, a `wz` turn) so the atlas actually contains the
robot's turning motion, and verify by per-ROW atlas hash rather than by eye.

**The pet `id` comes from the output directory name.** The renderer derives the
slug from `--out`'s last path segment, so rendering into a scratch directory
silently changes the pet's identity and the installed `pet.json` no longer
matches the gallery entry. Render into a directory named for the intended slug,
or fix `id` before installing.

**Ship a receipt in `pet.json`, then prove it by re-running.** Record the atlas
sha256, the atlas/frame geometry, the row list, the source motion and its
command, and the opaque-pixel floor. Then render TWICE and compare the two atlas
hashes — "deterministic" is a claim until the second run reproduces the bytes —
and assert the installed atlas hash equals the receipt's.

**Version the generator and the atlas in a repo.** A pet living only under
`HERMES_HOME` is lost on a reload or wipe, and the atlas alone cannot be
regenerated for a different subject.

## Sharing a pet

Ship two archives from the repo: the pet alone (drops straight into `pets/`) and
a kit that adds the generator so a stranger can rebuild every byte.

```
<slug>.zip       pet.json + spritesheet.webp + LICENSE
<slug>-kit.zip   the above + generator + README + THIRD_PARTY_NOTICES
```

**Check the upstream licence of anything you RENDERED before publishing it.** A
sprite atlas is a derivative work of its source asset, so it inherits that
asset's licence — not the licence of your renderer. A copyleft/reciprocal source
(e.g. CERN-OHL-S for hardware CAD) makes the atlas reciprocal too. Split the
package: **your generator keeps your licence, the rendered atlas carries the
upstream one**, reproduce the upstream licence text verbatim beside the atlas,
and point at the Source rather than redistributing the raw assets. State plainly
that reciprocal terms have consequences for combined works and that the notice
is not legal advice.

**Verify the export by round-tripping it, not by listing the zip.** Download the
published archive, extract it, and compare the atlas hash against the installed
one; a git blob SHA match plus a successful re-extract is the evidence. A zip
that exists is not a pet a stranger can install.

**A public gallery submission is a separate authorization.** Preparing and
publishing to your own repo does not authorize submitting to someone else's
index — ask.

## A pet in a browser surface

A pet that lives in a web page (a companion, a viewport) has the same contract
on the atlas but three extra failure modes. All three were hit for real.

**Vendor the 3D runtime; a missing `vendor/` kills the whole module.** An
`import * as THREE from './vendor/three.module.js'` that 404s fails the entire
module script — the page renders its header and nothing else, and the HTML
still returns 200. Check the import resolves before writing any scene code.

**Full-resolution CAD is not web-sized.** One million triangles is ~72 MB of
position+normal buffers. Simplify by **vertex clustering** (quantize to a grid
in metres, drop the triangles that collapse) and **recompute the normals from
the final triangles** — carrying source normals through a simplification
describes geometry that no longer exists. Measure the trade-off and ship the
coarsest grid that still reads:

```
grid 0.008   259,332 verts   6.1 MB   <- ship
grid 0.004   567,471 verts    14 MB
grid 0.002 1,054,119 verts    25 MB
```

**A surface is dead when its ASSETS are missing, not when its HTML is.** A
companion can ship with no `scene/` directory at all: the page loads, the HUD
paints, and the robot never appears. Verify the NETWORK (CDP `Network`), not
just `page_info()` — a 200 on the document says nothing about a 404 on
`scene/manifest.json`. Grep the page for every relative `fetch`/`import` and
assert each one resolves.

**DOM awareness: let the pet read the page it lives in.** A surface can report
its own document — title, headline, headings, tables and their row counts, film
sources, the hashes printed on the page, byte size — and react its expression to
what it finds (films -> thinking, several hashes -> review). Two rules: label a
fingerprint honestly (FNV-1a is not sha256), and **reading is never permission**
— `grants` stays false, as on every other verb.

**A self-induced MutationObserver loop never settles.** If the observer watches
the subtree the pet writes its own HUD into, every write triggers another read
and the fingerprint changes forever. Exclude the HUD from the observation, and
prove it by reading twice: the fingerprint must be identical.

## Pitfalls

- A pet only shows once one is installed AND selected (`enabled: true`).
- Inside a pipe/redirect (no TTY) terminal rendering is disabled by design.
- The petdex npm CLI installs to `~/.codex/pets`; Hermes uses its own
  profile-scoped `<HERMES_HOME>/pets/` instead — install through `hermes pets`.

## Verification

- `hermes pets doctor` reports `✓ ready` when a pet is installed, selected,
  enabled, and Pillow is importable.
- For a browser pet, also assert in a real browser that the CAD is present
  (link/joint count and a non-empty bounding box), that every relative asset
  returns 200, and that `dom()` reports a STABLE fingerprint across two reads.
