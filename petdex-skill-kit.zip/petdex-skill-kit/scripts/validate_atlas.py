#!/usr/bin/env python3
"""Validate a Hermes pet spritesheet against the atlas contract.

Catches the two defects that install cleanly and look fine in a thumbnail:
  * a row whose six frames are identical (a pose with no time term)
  * a frame that is nearly transparent (an off-camera or degenerate pose)

Change is measured by HASH, never by eye — subtle motion at 192px reads as
static to a human and to a vision model while every frame differs.

    python validate_atlas.py <pets-dir>/<slug>
    python validate_atlas.py <path/to/spritesheet.webp>

Exit 0 = every row animates and every frame is populated.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

FRAME_W, FRAME_H = 192, 208
FRAMES_PER_STATE = 6
CODEX_ROWS = ["idle", "running-right", "running-left", "waving", "jumping",
              "failed", "waiting", "running", "review"]
LEGACY_ROWS = ["idle", "wave", "run", "failed", "review", "jump", "extra1", "extra2"]
MIN_OPAQUE = 500          # per 192x208 frame; below this the pose is off-camera


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    target = Path(sys.argv[1])
    sheet = target / "spritesheet.webp" if target.is_dir() else target
    if not sheet.exists():
        print(f"FAIL no spritesheet at {sheet}")
        return 1

    im = Image.open(sheet)
    if im.mode != "RGBA":
        print(f"FAIL mode {im.mode} — a pet needs alpha or it draws as a rectangle")
        return 1
    cols, rows = im.width // FRAME_W, im.height // FRAME_H
    if im.width % FRAME_W or im.height % FRAME_H:
        print(f"FAIL {im.size} is not a whole number of {FRAME_W}x{FRAME_H} cells")
        return 1
    names = CODEX_ROWS if rows >= len(CODEX_ROWS) else LEGACY_ROWS
    print(f"  {sheet.name}: {im.size} = {cols} cols x {rows} rows -> "
          f"{'codex' if rows >= len(CODEX_ROWS) else 'legacy'} taxonomy")
    if cols < FRAMES_PER_STATE:
        print(f"FAIL only {cols} columns; {FRAMES_PER_STATE} frames are played per state")
        return 1

    bad = []
    for ri in range(rows):
        name = names[ri] if ri < len(names) else f"row{ri}"
        cells = [np.array(im.crop((k * FRAME_W, ri * FRAME_H,
                                   (k + 1) * FRAME_W, (ri + 1) * FRAME_H)))
                 for k in range(FRAMES_PER_STATE)]
        uniq = len({c.tobytes() for c in cells})
        opaque = [int((c[:, :, 3] > 0).sum()) for c in cells]
        low = min(opaque)
        flags = []
        if uniq < FRAMES_PER_STATE:
            flags.append(f"STATIC ({uniq}/{FRAMES_PER_STATE} distinct)")
        if low < MIN_OPAQUE:
            flags.append(f"NEARLY EMPTY (min {low} opaque px)")
        if flags:
            bad.append(name)
        print(f"    {name:15s} {uniq}/{FRAMES_PER_STATE} distinct · "
              f"min opaque {low:6,} {' '.join(flags)}")

    if target.is_dir():
        meta = target / "pet.json"
        if not meta.exists():
            print("FAIL no pet.json beside the sheet")
            return 1
        d = json.loads(meta.read_text(encoding="utf-8"))
        for k in ("id", "displayName", "spritesheetPath"):
            if not d.get(k):
                print(f"FAIL pet.json missing {k}")
                return 1
        if d["id"] != target.name:
            print(f"FAIL pet.json id {d['id']!r} != directory {target.name!r}")
            return 1

    if bad:
        print(f"FAIL rows need work: {', '.join(bad)}")
        return 1
    print("PASS every row animates and every frame is populated")
    return 0


if __name__ == "__main__":
    sys.exit(main())
