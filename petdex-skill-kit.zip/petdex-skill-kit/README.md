# petdex-skill-kit — a receipted pet for Hermes Agent

A drop-in evolution of the `petdex` skill, plus the generators that make a pet
**receipted and gait-faithful** rather than merely animated.

Drop `SKILL.md` + `scripts/` into `~/.hermes/skills/productivity/petdex/` and the
generators anywhere on `PATH`. No account, no gallery, no cloud.

## What it adds over the stock skill

| lesson | why |
|---|---|
| **Each locomotion row gets its OWN motion source** | replaying one walk at three yaws makes `running` / `running-right` / `running-left` the same gait in three costumes |
| **Ship a receipt in `pet.json`, then prove it** | render twice and compare hashes — "deterministic" is a claim until the second run reproduces the bytes |
| **A pet needs alpha; a film renderer does not produce it** | fork only the shade pass, keep the depth kernel and lighting identical |
| **The `id` comes from the output directory name** | render into a scratch dir and the installed `pet.json` no longer matches the slug |
| **A browser pet: vendor three.js, simplify the CAD, verify the network** | a missing `vendor/` or `scene/` makes a page silently dead while the HTML still returns 200 |
| **DOM awareness: the pet reads its own page** | films → thinking, several hashes → review; reading is never permission, `grants` stays false |
| **A self-induced MutationObserver loop never settles** | exclude the HUD you write to; prove it by reading twice and comparing the fingerprint |

## Layout

```
SKILL.md                     the evolved skill (drop-in)
scripts/validate_atlas.py    geometry, alpha, per-row uniqueness, opaque floor
generators/asimov_pet.py     CAD -> spritesheet + pet.json (+ --receipt)
generators/webgl_prep.py     STL -> scene/manifest.json + per-link .bin (--grid)
generators/companion.mjs     CDP driver: status|state|say|pose|move|ledger|dom
```

## Use

```bash
# terminal pet
python generators/asimov_pet.py --model-dir <model> --out <pets>/asimov-cad \
  --trace walk.json --trace-turn turn.json --receipt

# validate before installing
python scripts/validate_atlas.py <pets>/asimov-cad

# browser scene (web-sized: 0.008 grid -> 259k verts / 6.1 MB)
python generators/webgl_prep.py --model <model> --out ./scene --grid 0.008
```

## Licence — read `NOTICES.md`

The **generator and skill are MIT**. A rendered atlas is a **derivative of its
source asset** and inherits that asset's terms — for Asimov-1 hardware CAD that
is CERN-OHL-S-2.0 (reciprocal). Split the package: your generator keeps MIT,
the rendered atlas carries the upstream licence, reproduce the licence text
beside the atlas, and point at the source rather than redistributing the raw
assets. This is not legal advice.
